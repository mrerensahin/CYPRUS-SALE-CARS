from flask import Flask, render_template, request, redirect, session, url_for, flash
from flask_bcrypt import Bcrypt
import sqlite3
import os
from werkzeug.utils import secure_filename
from datetime import datetime, timedelta

app = Flask(__name__)
app.secret_key = 'supersecretkey'
UPLOAD_FOLDER = 'static/uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

bcrypt = Bcrypt(app)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def create_tables():
    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE,
            password TEXT,
            is_admin INTEGER DEFAULT 0,
            firstname TEXT,
            lastname TEXT,
            email TEXT,
            phone TEXT,
            photo TEXT
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS vehicles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT,
            description TEXT,
            price REAL,
            duration INTEGER,
            image TEXT,
            user_id INTEGER,
            created_at TEXT
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS bids (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            vehicle_id INTEGER,
            amount REAL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS favorites (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            vehicle_id INTEGER,
            UNIQUE(user_id, vehicle_id)
        )
    """)
    conn.commit()
    conn.close()

def create_sales_table():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS sales (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            vehicle_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            price INTEGER NOT NULL,
            sale_date TEXT NOT NULL,
            FOREIGN KEY(vehicle_id) REFERENCES vehicles(id),
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
    ''')
    conn.commit()
    conn.close()

create_tables()
create_sales_table()

def get_vehicles():
    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM vehicles")
    vehicles = cursor.fetchall()
    conn.close()
    return vehicles

@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = bcrypt.generate_password_hash(request.form['password']).decode('utf-8')
        conn = sqlite3.connect("database.db")
        cursor = conn.cursor()
        try:
            cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, password))
            conn.commit()
            flash("Kayıt başarılı.")
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash("Bu kullanıcı adı zaten var.")
        finally:
            conn.close()
    return render_template("register.html")

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password_input = request.form['password']
        conn = sqlite3.connect("database.db")
        cursor = conn.cursor()
        cursor.execute("SELECT id, password, is_admin FROM users WHERE username = ?", (username,))
        user = cursor.fetchone()
        conn.close()
        if user and bcrypt.check_password_hash(user[1], password_input):
            session['user_id'] = user[0]
            session['username'] = username
            session['is_admin'] = bool(user[2])
            return redirect(url_for('admin_dashboard' if session['is_admin'] else 'dashboard'))
        else:
            flash("Geçersiz bilgiler.")
    return render_template("login.html")

@app.route('/logout')
def logout():
    session.clear()
    flash("Çıkış yapıldı.")
    return redirect(url_for('login'))

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session or session.get('is_admin'):
        return redirect(url_for('login'))

    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()
    cursor.execute("SELECT photo FROM users WHERE id = ?", (session['user_id'],))
    photo = cursor.fetchone()[0] or 'default.png'
    conn.close()

    return render_template("dashboard.html", username=session['username'], photo=photo, vehicles=get_vehicles())

@app.route('/favorites')
def favorites():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    user_id = session['user_id']
    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()

    # Favori araçlar
    cursor.execute("""
        SELECT vehicles.*
        FROM favorites
        JOIN vehicles ON favorites.vehicle_id = vehicles.id
        WHERE favorites.user_id = ?
    """, (user_id,))
    vehicles = cursor.fetchall()

    # Profil fotoğrafı
    cursor.execute("SELECT photo FROM users WHERE id = ?", (user_id,))
    result = cursor.fetchone()
    photo = result[0] if result and result[0] else 'default.png'

    conn.close()
    return render_template("dashboard.html", username=session['username'], photo=photo, vehicles=vehicles)


@app.route('/toggle-favorite/<int:vehicle_id>', methods=['POST'])
def toggle_favorite(vehicle_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    user_id = session['user_id']
    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()
    
    cursor.execute("SELECT 1 FROM favorites WHERE user_id = ? AND vehicle_id = ?", (user_id, vehicle_id))
    exists = cursor.fetchone()

    if exists:
        cursor.execute("DELETE FROM favorites WHERE user_id = ? AND vehicle_id = ?", (user_id, vehicle_id))
        flash("Favoriden çıkarıldı.")
    else:
        cursor.execute("INSERT OR IGNORE INTO favorites (user_id, vehicle_id) VALUES (?, ?)", (user_id, vehicle_id))
        flash("Favorilere eklendi.")

    conn.commit()
    conn.close()
    return redirect(url_for('vehicle_detail', vehicle_id=vehicle_id))

@app.route('/admin/dashboard')
def admin_dashboard():
    if 'user_id' not in session or not session.get('is_admin'):
        return redirect(url_for('login'))
    return render_template("admin_dashboard.html", username=session['username'], vehicles=get_vehicles())

@app.route('/add-vehicle', methods=['GET', 'POST'])
def add_vehicle():
    if 'user_id' not in session or not session.get('is_admin'):
        return redirect(url_for('login'))
    if request.method == 'POST':
        title = request.form.get('title')
        description = request.form.get('description')
        price = request.form.get('price')
        duration = request.form.get('duration')
        image = request.files.get('image')
        if image and allowed_file(image.filename):
            filename = secure_filename(image.filename)
            path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            image.save(path)
            created_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            conn = sqlite3.connect("database.db")
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO vehicles (title, description, price, duration, image, user_id, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (title, description, price, duration, filename, session['user_id'], created_at))
            conn.commit()
            conn.close()
            flash("Araç eklendi.")
            return redirect(url_for('admin_dashboard'))
    return render_template("vehicle_add.html")

@app.route('/delete-vehicle/<int:vehicle_id>', methods=['POST'])
def delete_vehicle(vehicle_id):
    if 'user_id' not in session or not session.get('is_admin'):
        return redirect(url_for('login'))
    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()
    cursor.execute("SELECT image FROM vehicles WHERE id = ?", (vehicle_id,))
    img = cursor.fetchone()
    if img:
        img_path = os.path.join(app.config['UPLOAD_FOLDER'], img[0])
        if os.path.exists(img_path):
            os.remove(img_path)
    cursor.execute("DELETE FROM vehicles WHERE id = ?", (vehicle_id,))
    conn.commit()
    conn.close()
    flash("Araç silindi.")
    return redirect(url_for('admin_dashboard'))

@app.route('/vehicle/<int:vehicle_id>', methods=['GET', 'POST'])
def vehicle_detail(vehicle_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    from_page = request.args.get('from_page', 'dashboard')
    if from_page not in ['dashboard', 'favorites']:
        from_page = 'dashboard'

    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM vehicles WHERE id = ?", (vehicle_id,))
    vehicle = cursor.fetchone()

    if not vehicle:
        conn.close()
        flash("Araç bulunamadı.")
        return redirect(url_for('dashboard'))

    created_at = datetime.strptime(vehicle[7], "%Y-%m-%d %H:%M:%S")
    deadline = created_at + timedelta(minutes=int(vehicle[4]))
    now = datetime.now()
    is_ended = now > deadline

    cursor.execute("SELECT MAX(amount) FROM bids WHERE vehicle_id = ?", (vehicle_id,))
    highest_bid = cursor.fetchone()[0]

    cursor.execute("SELECT 1 FROM favorites WHERE user_id = ? AND vehicle_id = ?", (session['user_id'], vehicle_id))
    is_favorited = cursor.fetchone() is not None

    if is_ended:
        cursor.execute("SELECT id FROM sales WHERE vehicle_id = ?", (vehicle_id,))
        already_sold = cursor.fetchone()
        if not already_sold:
            cursor.execute("""
                SELECT user_id, amount FROM bids
                WHERE vehicle_id = ?
                ORDER BY amount DESC LIMIT 1
            """, (vehicle_id,))
            winner = cursor.fetchone()
            if winner:
                user_id, price = winner
                sale_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                cursor.execute("""
                    INSERT INTO sales (vehicle_id, user_id, price, sale_date)
                    VALUES (?, ?, ?, ?)
                """, (vehicle_id, user_id, price, sale_date))
                conn.commit()

    if request.method == 'POST' and not is_ended:
        try:
            bid = float(request.form.get('bid_amount'))
            if bid > (highest_bid or vehicle[3]):
                cursor.execute("INSERT INTO bids (user_id, vehicle_id, amount) VALUES (?, ?, ?)",
                               (session['user_id'], vehicle_id, bid))
                conn.commit()
                flash("Teklif verildi.")
                return redirect(url_for('vehicle_detail', vehicle_id=vehicle_id, from_page=from_page))
            else:
                flash(f"Teklif yetersiz. Şu anki en yüksek teklif: {highest_bid or vehicle[3]} ₺")
        except:
            flash("Geçersiz teklif girildi.")

    cursor.execute("SELECT MAX(amount) FROM bids WHERE vehicle_id = ?", (vehicle_id,))
    highest_bid = cursor.fetchone()[0]
    conn.close()

    return render_template("vehicle_detail.html",
                           vehicle=vehicle,
                           highest_bid=highest_bid,
                           is_ended=is_ended,
                           deadline=deadline,
                           is_favorited=is_favorited,
                           from_page=from_page)




@app.route('/profile', methods=['GET', 'POST'])
def profile():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    if request.method == 'POST':
        if 'photo' in request.files:
            photo = request.files['photo']
            if photo.filename != '':
                filename = f"profile_{session['user_id']}.jpg"
                filepath = os.path.join('static/profile_images', filename)
                os.makedirs(os.path.dirname(filepath), exist_ok=True)
                photo.save(filepath)
                cursor.execute("UPDATE users SET photo = ? WHERE id = ?", (filename, session['user_id']))

        firstname = request.form.get('firstname')
        lastname = request.form.get('lastname')
        email = request.form.get('email')
        phone = request.form.get('phone')

        cursor.execute("""
            UPDATE users
            SET firstname = ?, lastname = ?, email = ?, phone = ?
            WHERE id = ?
        """, (firstname, lastname, email, phone, session['user_id']))

        conn.commit()
        flash("Profil güncellendi.")

    cursor.execute("""
        SELECT firstname, lastname, email, phone, username, photo
        FROM users WHERE id = ?
    """, (session['user_id'],))
    user = cursor.fetchone()
    conn.close()

    user_info = {
        'firstname': user[0] or '',
        'lastname': user[1] or '',
        'email': user[2] or '',
        'phone': user[3] or '',
        'username': user[4],
        'photo': user[5] or 'default.png'
    }

    return render_template("user_profile.html", user=user_info)

@app.route('/admin/reports')
def admin_reports():
    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()
    cursor.execute("""
        SELECT vehicles.title, users.username, sales.price, sales.sale_date
        FROM sales
        JOIN vehicles ON sales.vehicle_id = vehicles.id
        JOIN users ON sales.user_id = users.id
        ORDER BY sales.sale_date DESC
    """)
    results = cursor.fetchall()
    conn.close()
    sales = [{
        'vehicle_title': row[0],
        'username': row[1],
        'price': row[2],
        'sale_date': row[3]
    } for row in results]
    return render_template("admin_reports.html", sales=sales)

@app.route('/admin/bids')
def admin_bids():
    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()
    cursor.execute("""
        SELECT bids.amount, users.username, vehicles.title, bids.created_at
        FROM bids
        JOIN users ON bids.user_id = users.id
        JOIN vehicles ON bids.vehicle_id = vehicles.id
        ORDER BY bids.created_at DESC
    """)
    bid_rows = cursor.fetchall()
    conn.close()
    bids = [{
        'amount': row[0],
        'username': row[1],
        'vehicle_title': row[2],
        'created_at': row[3]
    } for row in bid_rows]
    return render_template("admin_bids.html", bids=bids)

@app.route('/my-bids')
def my_bids():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    user_id = session['user_id']
    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()
    cursor.execute("""
        SELECT bids.amount, vehicles.title, bids.created_at, vehicles.id
        FROM bids
        JOIN vehicles ON bids.vehicle_id = vehicles.id
        WHERE bids.user_id = ?
        ORDER BY bids.created_at DESC
    """, (user_id,))
    results = cursor.fetchall()
    bids = []
    for amount, title, created_at, vehicle_id in results:
        cursor.execute("""
            SELECT 1 FROM sales
            WHERE vehicle_id = ? AND user_id = ?
        """, (vehicle_id, user_id))
        is_winner = cursor.fetchone() is not None
        bids.append({
            'vehicle_title': title,
            'amount': amount,
            'created_at': created_at,
            'is_winner': is_winner
        })
    conn.close()
    return render_template('user_bids.html', bids=bids)

if __name__ == '__main__':
    app.run(debug=True)
